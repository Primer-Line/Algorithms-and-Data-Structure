#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stack.h"
#include"LinkedList.h"
#define MAXLENGTH 100
#pragma warning(disable:4996)
typedef int dataType;
typedef unsigned int UINT;
typedef struct HuffmanTree
{
	int weight;
	char data;
	struct HuffmanTree* left;
	struct HuffmanTree* right;
	struct HuffmanTree* parent;
}TreeNode;
typedef struct HuffmanCode
{
	char bit[MAXLENGTH];
	char data; 
}Code;
void createHuffmanTree(TreeNode**,TreeNode***,char**,UINT* n);
void preOrder(TreeNode* root);
void inOrder(TreeNode* root);
void laOrder(TreeNode* root);
void createHuffmanCode(char* str,Code** code,int);
char* reverseCode(char* dest);
char* reverseCode(char* dest)
{
	int len=strlen(dest),i=0;
	char* arg = (char*)malloc(sizeof(char)*(len+1)),*s;
	memset(arg,0,sizeof(char)*(len+1));
	s = arg;
	while(--len>=0)*s++=*(dest+len);
	*s='\0';
	return arg;
}
void createHuffmanCode(char* str,Code** code,int n)
{
	int i;
	char s[10000]="";
	memset(s,0,sizeof(s));
	while(*str)
	{
		i=1;
		while(i<=n&&code[i]->data!=*str)i++;
		strcat(s,reverseCode(code[i]->bit));
		str++;
	}
	printf("%s\n",s);
}
void createHuffmanTree(TreeNode** root,TreeNode*** nodes,char** s,UINT* n)
{
	UINT len,i,key,val = 0,count[128][2]={0};
	void* data1,*data2;
	TreeNode** node,*treeNode1,*treeNode2;
	List* head=NULL,*p = NULL,*h=NULL;
	char str[100];
	printf("��������������:\n");
	scanf("%s",str);
	if(strcmp(str,"")==0)return;
	len = strlen(str);
	strcpy(*s,str);
	for(i=0;i<len;i++)
	{
		count[(int)str[i]][0]++;
		count[(int)str[i]][1] = (int)str[i];
	}
	for(i=0;i<128;i++)
	{
		if(count[i][0]>0)insertSort(&head,&count[i][0],&count[i][1]);
	}
	len = getLinkedListLenth(head);
	if(len<2)return;
	*n = len;
	node = (TreeNode** )malloc(sizeof(struct HuffmanTree*)*(2*len));
	if(!node)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	p = head;
	printf("���������ַ��ͳ���Ƶ��:\n");
	for(key=1;key<=len;key++)
	{
		node[key]=(TreeNode* )malloc(sizeof(struct HuffmanTree ));
		if(!node[key])
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(node[key],0,sizeof(node[key]));
		node[key]->left=NULL;
		node[key]->right=NULL;
		node[key]->weight=*(int*)p->data;
		node[key]->data=(char)(*(int*)p->elem);
		printf("%c %d\n",node[key]->data,node[key]->weight);
		insertSort(&h,&(node[key]->weight),node[key]);
		p=p->next;
	}
	free(head);
	for(key=len+1;key<2*len;key++)
	{
		node[key]=(TreeNode* )malloc(sizeof(struct HuffmanTree));
		if(!node[key])
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(node[key],0,sizeof(node[key]));
		deleteHeadNode(&h,&data1,&treeNode1);
		deleteHeadNode(&h,&data2,&treeNode2);	
		node[key]->left=treeNode1;
		node[key]->right=treeNode2;
		treeNode1->parent=node[key];
		treeNode2->parent=node[key];
		node[key]->weight=(*(int*)data1)+(*(int*)data2);
		val+=node[key]->weight;
		insertNode(&h,&(node[key]->weight),node[key]);
	}
	*root = h->elem;
	printf("���������Ĵ�Ȩ·������:%d\n",val);
	printf("��������ǰ�����:\n");
	preOrder(*root);
	printf("\n");
	printf("���������������:\n");
	inOrder(*root);
	printf("\n");
	printf("���������������:\n");
	laOrder(*root);
	printf("\n");
	*nodes=node;
}
void preOrder(TreeNode* root)
{
	if(!root)return;
	printf("%d ",root->weight);
	preOrder(root->left);
	preOrder(root->right);
}
void inOrder(TreeNode* root)
{
	if(!root)return;
	inOrder(root->left);
	printf("%d ",root->weight);
	inOrder(root->right);
}
void laOrder(TreeNode* root)
{
	if(!root)return;
	laOrder(root->left);
	laOrder(root->right);
	printf("%d ",root->weight);
}
int main()
{
	int i,n,key;
	char* str=(char*)malloc(sizeof(char)*MAXLENGTH);
	TreeNode** nodes=NULL,*node,*root=NULL;
	Code** code;
	printf("����������\n");
	createHuffmanTree(&root,&nodes,&str,&n);
	code=(Code** )malloc((n+1)*sizeof(struct HuffmanCode* ));
	if(!code)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	for(i=1;i<=n;i++)
	{
		node=nodes[i];
		code[i]=(Code* )malloc(sizeof(struct HuffmanCode));
		if(!code[i])
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(code[i]->bit,0,sizeof(code[i]->bit));
		code[i]->data=node->data;
		key=0;
		while(node!=root)
		{
			code[i]->bit[key++]=node==node->parent->left?'0':'1';
			node=node->parent;
		}
	}
	printf("���ַ��Ĺ���������:\n");
	for(i=1;i<=n;i++)printf("%c %s\n",code[i]->data,reverseCode(code[i]->bit));
	printf("�ַ����еĹ���������:\n");
	createHuffmanCode(str,code,n);
	free(str);
	free(nodes);
	free(root);
	return 0;
}