typedef unsigned int UINT;
typedef struct LinkedList
{
	elemType data;
	elemType elem;
	struct LinkedList* next;
}List;
void addNode(List** head, elemType data,elemType);
void insertNode(List** head,elemType data,elemType);
void deleteHeadNode(List** head,elemType* data,elemType*);
UINT getLinkedListLenth(List* head);
UINT getLinkedListLenth(List* head)
{
	return !head?0:getLinkedListLenth(head->next)+1;
}
int cmp(const void* a,const void* b)
{
	int* m = (int*)a,*n = (int*)b;
	if(*m<*n)return -1;
	if(*m==*n)return 0;
	return 1;
}
void insertNode(List** head,elemType data,elemType elem)
{
	List* q,*p;
	if(!(*head))
	{
		(*head)=(List* )malloc(sizeof(struct LinkedList));
		if(!(*head))
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(*head,0,sizeof(*head));
		(*head)->data=data;
		(*head)->elem=elem;
		(*head)->next=NULL;
		return;
	}
	if(cmp(data,(*head)->data)!=1)
	{
		q=(List* )malloc(sizeof(struct LinkedList));
		if(!q)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(q,0,sizeof(q));
		q->data=data;
		q->elem=elem;
		q->next=(*head);
		(*head)=q;
		return;
	}
	q=(*head);
	p=(List* )malloc(sizeof(struct LinkedList));
	if(!p)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(p,0,sizeof(p));
	p->data=data;
	p->elem=elem;
	while(q)
	{
		if(cmp(q->data,data)!=1&&(!q->next||cmp(q->next->data,data)!=-1))
		{
			p->next=q->next;
			q->next=p;
			break;
		}
		q=q->next;
	}
}
void addNode(List** head,elemType data,elemType elem)
{
	List* p,*q;
	if(!(*head))
	{
		(*head)=(List* )malloc(sizeof(struct LinkedList));
		if(!(*head))
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(*head,0,sizeof(*head));
		(*head)->data=data;
		(*head)->elem=elem;
		(*head)->next=NULL;
		return;
	}
	p=(*head);
	while(p->next)p=p->next;
	q=(List* )malloc(sizeof(struct LinkedList));
	if(!q)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(q,0,sizeof(q));
	q->data=data;
	q->elem=elem;
	q->next=p->next;
	p->next=q;
}
void deleteHeadNode(List** head,elemType* data,elemType* elem)
{
	*data=(*head)->data;
	*elem=(*head)->elem;
	(*head)=(*head)->next;
}
void insertSort(List** head,elemType data,elemType elem)
{
	List* p,*q;
	if(!(*head))
	{
		(*head)=(List* )malloc(sizeof(List));
		if(!(*head))
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(*head,0,sizeof(*head));
		(*head)->data=data;
		(*head)->elem=elem;
		(*head)->next=NULL;
		return;
	}
	q=(List* )malloc(sizeof(List));
	if(!q)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(q,0,sizeof(q));
	q->data=data;
	q->elem=elem;
	if(cmp(data,(*head)->data)!=1)
	{
		q->next=(*head);
		(*head) = q;
		return;
	}
	p=(*head);
	while(p)
	{
		if(cmp(p->data,data)!=1&&(!p->next||cmp(p->next->data,data)!=-1))
		{
			q->next=p->next;
			p->next=q;
			break;
		}
		p=p->next;
	}	
}
void destroyLinkedList(List** head)
{
	List* h;
	while(*head)
	{
		h = (*head)->next;
		free(*head);
		*head=NULL;
		*head = h;
	}
}








