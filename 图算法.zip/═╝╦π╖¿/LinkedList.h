typedef struct LinkedList
{
	int adjVex1;
	int adjVex2;
	int weight;
	struct LinkedList* next;
}linkedList; 
linkedList* initList()
{
	linkedList* list=NULL;
	return list;
}
linkedList* insert(linkedList* list,int adjVex1,int adjVex2,int weight)
{
	linkedList* h,*q;
	if(!list)
	{
		list=(linkedList* )malloc(sizeof(struct LinkedList));
		if(!list)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		list->adjVex1=adjVex1;
		list->adjVex2=adjVex2;
		list->weight=weight;
		list->next=NULL;
		return list;
	}
	h=(linkedList* )malloc(sizeof(struct LinkedList));
	h->adjVex1=adjVex1;
	h->adjVex2=adjVex2;
	h->weight=weight;
	if(!h)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	if(h->weight<=list->weight)
	{
		h->next=list;
		return h;
	}
	q=list;
	while(q&&!(h->weight>=q->weight&&(!q->next||q->next->weight>=h->weight)))
	{
		q=q->next;
	}
	h->next=q->next;
	q->next=h;
	return list;	
}
linkedList* deleteHeadNode(linkedList* list,linkedList** node)
{
	*node=list;
	list=list->next;
	return list;
}
int existNode(linkedList* list,int adjVex1,int adjVex2)
{
	linkedList* h=list;
	while(h)
	{
		if(h->adjVex1==adjVex1&&h->adjVex2==adjVex2||h->adjVex1==adjVex2&&h->adjVex2==adjVex1)
		{
			return 1;
		}
		h=h->next;
	}
	return 0;
}
int listEmpty(linkedList* list)
{
	return !list?0:1;
}
linkedList* deleteNode(linkedList* list)
{
	list=list->next;
	return list;
}