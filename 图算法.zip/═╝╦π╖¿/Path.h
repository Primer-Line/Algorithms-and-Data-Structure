#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct Path
{
	int a;
	int b;
	int weight;
	struct Path* next;	
}path;
typedef struct AllPath
{
	path* p;
	struct AllPath* next;
}allPath;
allPath* addPath(path* p,allPath* all);
path* insertPath(path* p,int a,int b,int weight);
int getWeight(path* p);
path* insertPath(path* pa,int a,int b,int weight)
{
	path* p,*h,*k,*s;
	if(!pa)
	{
		p=(path* )malloc(sizeof(struct Path));
		if(!p)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(p,0,sizeof(p));
		p->a=a;
		p->b=b;
		p->weight=weight;
		p->next=NULL;
		return p;
	}
	p=(path* )malloc(sizeof(struct Path));
	if(!p)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(p,0,sizeof(p));
	p->a=pa->a;
	p->b=pa->b;
	p->weight=pa->weight;
	p->next=NULL;
	k=p;
	h=pa->next;
	/*
	while(k->next)
	{	
		k=k->next;
	}
	*/
	while(h)
	{
		s=(path* )malloc(sizeof(struct Path));
		if(!s)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(s,0,sizeof(s));
		s->a=h->a;
		s->b=h->b;
		s->weight=h->weight;
		s->next=k->next;
		k->next=s;
		k=k->next;
		h=h->next;
	}
	//p->next=NULL;
	s=(path* )malloc(sizeof(struct Path));
	if(!s)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(s,0,sizeof(s));
	s->a=a;
	s->b=b;
	s->weight=weight;
	/*
	h=p;
	while(h->next)
	{	
		h=h->next;
	}
	*/
	s->next=k->next;
	k->next=s;
	return p;	
}
path* deletePath(path* p)
{
	free(p);
	p=NULL;
	return p;
}
allPath* addPath(path* p,allPath* all)
{
	allPath* aPath;
	if(!all)
	{
		all=(allPath* )malloc(sizeof(struct AllPath));
	    all->p=p;
		return all;
	}
	if(getWeight(p)<getWeight(all->p))
	{
		aPath=(allPath* )malloc(sizeof(struct AllPath));
	    aPath->p=p;
		free(all);
		return aPath;
	}	
	return all;	
}
int getWeight(path* p)
{
	return p?getWeight(p->next)+p->weight:0;
}
