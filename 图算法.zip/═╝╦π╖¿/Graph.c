#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Stack.h"
#include"Queue.h"
#include"LinkedList.h"
#include"Path.h"
vertexNode** insertNode(vertexNode** node,int adjvex,int firstvex,int weight);
int* initVisit(int* visited,graph* g);
int allVisited(vertexNode** nodes,graph* g,int* visited,vertexNode** node);
void minSpanTree_Prim(linkedList* list,vertexNode** nodes,graph* g,int* visited);
int find(int* parent,int a);
allPath** getPath(allPath** all,int a,path** p,vertexNode* node,int* b,int* weight,int* visited);
void showPath(vertexNode** nodes,allPath* all);
vertexNode** insertNode(vertexNode** node,int adjvex,int firstvex,int weight)
{
	arcNode* s,*q;
	if(!node[adjvex]->firstArc)
	{
		node[adjvex]->firstArc=(arcNode* )malloc(sizeof(struct ArcNode));
		if(!node[adjvex]->firstArc)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		node[adjvex]->firstArc->adjvex=firstvex;
		node[adjvex]->firstArc->info=weight;
		node[adjvex]->firstArc->next=NULL;
	}
	else
	{
		s=(arcNode* )malloc(sizeof(struct ArcNode));
		if(!s)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		s->adjvex=firstvex;
		s->info=weight;
		q=node[adjvex]->firstArc;
		if(firstvex<q->adjvex) 
		{
			s->next=q;
			node[adjvex]->firstArc=s;
			return node;
		}
		while(q&&!(q->adjvex<s->adjvex&&(!q->next||s->adjvex<q->next->adjvex)))
		{
			q=q->next;
		}
		s->next=q->next;
		q->next=s;
	}
	return node;
}
int allVisited(vertexNode** nodes,graph* g,int* visited,vertexNode** node)
{
	int i;
	for(i=0;i<g->vexnum;i++)
	{
		if(!visited[i])
		{
			*node=nodes[i];
			return 0;
		}
	}
	return 1;
}
int allNodeVisited(graph* g,int* visited)
{
	int i;
	for(i=0;i<g->vexnum;i++)
	{
		if(!visited[i])
		{
			return 0;
		}
	}
	return 1;
}

void union_Set(int* parent,int* rank,int a,int b)
{
	a=find(parent,a);
	b=find(parent,b);
	if(rank[a]>rank[b])
	{
		parent[b]=a;
	}
	else
	{
		parent[a]=b;
		if(rank[a]==rank[b])
		{
			rank[b]++;
		}
	}
}
int find(int* parent,int a)
{
	if(parent[a]!=a)
	{
		a=find(parent,parent[a]);
	}
	return a;
}
void dfs(stack* sHead,vertexNode** nodes,graph* g,int* visited)
{
	vertexNode* node;
	struct ArcNode* h;
	visited[0]=1;
	sHead=push(sHead,nodes[0]);
	node=nodes[0];
	printf("�����������:\n");
	printf("%c",node->data);
	while(1)
	{
		h=node->firstArc;
		while(h&&visited[h->adjvex])
		{
			h=h->next;
		}
		if(h)
		{
			visited[h->adjvex]=1;
			node=nodes[h->adjvex];
			printf("%c",node->data);
			sHead=push(sHead,nodes[h->adjvex]);
		}
		else
		{
			if(!stackEmpty(sHead))
			{
				sHead=pop(sHead,&node);
			}
			else
			{
				if(allVisited(nodes,g,visited,&node))
				{
					break;
				}
			}
		}		
	}
	printf("\n");
}
void bfs(linkQueue* lQueue,vertexNode** nodes,graph* g,int* visited)
{
	vertexNode* node;
	struct ArcNode* h;
	visited=initVisit(visited,g);
	visited[0]=1;
	lQueue=enQueue(lQueue,nodes[0]);
	printf("�����������:\n");
	printf("%c",nodes[0]->data);
	while(!queueEmpty(lQueue))
	{
		lQueue=deQueue(lQueue,&node);
		h=node->firstArc;
		while(h)
		{
			if(!visited[h->adjvex])
			{
				visited[h->adjvex]=1;
				printf("%c",nodes[h->adjvex]->data);
				lQueue=enQueue(lQueue,nodes[h->adjvex]);
			}
			h=h->next;
		}
	}
	printf("\n");
}
void minSpanTree_Prim(linkedList* list,vertexNode** nodes,graph* g,int* visited)
{
	vertexNode* node;
	linkedList* listNode;
	arcNode* h;
	int adjVex;
	node=nodes[0];
	visited=initVisit(visited,g);
	visited[0]=1;
	adjVex=0;
	printf("��С������(Prim�㷨):\n");
	while(!allNodeVisited(g,visited))
	{
		h=node->firstArc;
		while(h)
		{
			if(!visited[h->adjvex])//0�ѷ���
			{
				list=insert(list,adjVex,h->adjvex,h->info);//����0,1,7->0,3,5   
				//����3,1,9->3,4,15->3,5,6
			}
			h=h->next;
		}
		do
		{
			list=deleteHeadNode(list,&listNode);//6->3 5
		}while(visited[listNode->adjVex1]&&visited[listNode->adjVex2]);
		printf("%c->%c %d\n",nodes[listNode->adjVex1]->data,nodes[listNode->adjVex2]->data,listNode->weight);//0,3,5
		if(!visited[listNode->adjVex2])
		{
			//here->3
			visited[listNode->adjVex2]=1;//visit[3]=1->d����
			node=nodes[listNode->adjVex2];//3
			adjVex=listNode->adjVex2;//��ǰλ��Ϊ3
		}
		else if(!visited[listNode->adjVex1])
		{
			visited[listNode->adjVex1]=1;
			node=nodes[listNode->adjVex1];
			adjVex=listNode->adjVex1;
		}
	} 
}
void minSpanTree_Kruskal(int arr[][3],vertexNode** nodes,graph* g,int* visited)
{
	linkedList* listNode;
	linkedList* list=initList();
	int i,num=0,*parent,*rank;
	visited=initVisit(visited,g);
	printf("��С������(Kruskal�㷨):\n");
	parent=(int* )malloc(g->vexnum*sizeof(int));
	rank=(int* )malloc(g->vexnum*sizeof(int));
	for(i=0;i<g->vexnum;i++)
	{
		parent[i]=i;
		rank[i]=0;
	}
	for(i=0;i<g->arcnum;i++)
	{
		list=insert(list,arr[i][0],arr[i][1],arr[i][2]);
	}
	while(num++<g->vexnum-1)
	{
		do
		{
			list=deleteHeadNode(list,&listNode);
		}while(find(parent,listNode->adjVex1)==find(parent,listNode->adjVex2));
		union_Set(parent,rank,listNode->adjVex1,listNode->adjVex2);
		printf("%c->%c %d\n",nodes[listNode->adjVex1]->data,nodes[listNode->adjVex2]->data,listNode->weight);
	}
}
int* initVisit(int* visited,graph* g)
{
	int i;
	for(i=0;i<g->vexnum;i++)
	{
		visited[i]=0;
	}
	return visited;
}
/*
path* createPath(path* p,path* q)
{
	if(!p)
	{
		p=(path* )malloc(sizeof(struct Path));
		if(!p)
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset(p,0,sizeof(p));
	}
	p->next=q;
	p=p->next;
	return p;
}
*/
path* comparePath(path* a,path* b)
{
	return !a?b:(getWeight(a)<getWeight(b)?a:b);
}
void shortPath_Dijkstra(vertexNode** nodes,graph* g)
{
	int* visited=(int* )malloc(g->vexnum*sizeof(int)),weight,a,b,i;
	path** p=(path** )malloc(g->vexnum*sizeof(struct Path));
	allPath** all=(allPath** )malloc(g->vexnum*sizeof(struct AllPath));
	for(i=0;i<g->vexnum;i++)
	{
		all[i]=NULL;
		p[i]=NULL;
	}
	printf("���·��(Dijkstra�㷨):\n");
	visited=initVisit(visited,g);
	a=0;
	i=0;
	while(++i<=g->vexnum-1)
	{
		all=getPath(all,a,p,nodes[a],&b,&weight,visited);
		visited[a]=1;
		a=b;
	}
	i=0;
	printf("%c->%c",nodes[0]->data,nodes[0]->data);
	printf("  0\n");
	while(++i<=g->vexnum-1)
	{
		showPath(nodes,all[i]);
	}	
}
void showPath(vertexNode** nodes,allPath* all)
{
	path* q;
	allPath* h=all;
	q=h->p;
	printf("%c->",nodes[0]->data);
	while(q)
	{
		if(q->next)
		{
			printf("%c->",nodes[q->b]->data);
		}
		else
		{
			printf("%c",nodes[q->b]->data);
		}
		q=q->next;
	}
	printf("  %d\n",getWeight(all->p));
}
allPath** getPath(allPath** all,int a,path** p,vertexNode* node,int* b,int* min,int* visited)
{
	arcNode* h=node->firstArc;
	path* pa=p[a],*ps=NULL;
	while(h)
	{
		if(!visited[h->adjvex])
		{
			*min=h->info;
			*b=h->adjvex;
			break;
		}
		h=h->next;
	}
	while(h)
	{
		if(!visited[h->adjvex])
		{
			ps=insertPath(pa,a,h->adjvex,h->info);//0->0=0  0->1=20 0->0->1 p[d]
			p[h->adjvex]=comparePath(p[h->adjvex],ps);
			all[h->adjvex]=addPath(p[h->adjvex],all[h->adjvex]);//1->4 0->1=20 0->4=4 all[1]->p=pa;
			if(h->info<(*min))
			{
				*min=h->info;
				*b=h->adjvex;
			}
		}
		h=h->next;
	}
	return all;
}
void shortPath_floy(vertexNode** nodes,graph* g)
{
	
}
int main()
{
	vertexNode** nodes;
	struct ArcNode* q;
	graph* g;
	int num,i,p,*visited;
	stack* sHead=initStack();
	linkQueue* lQueue=initQueue();
	linkedList* list=initList();
	//int arr[][3]={{0,5,14},{0,1,7},{0,2,9},{1,2,10},{1,3,15},{3,4,6},{2,3,11},{2,5,2},{5,4,9}};
	//char ch[]={'a','b','c','d','e','f'};
	int arr[][3]={{0,3,5},{0,1,7},{1,2,8},{1,3,9},{2,4,5},{1,4,7},{3,5,6},{3,4,15},{5,6,11},{4,6,9},{4,5,8}};
	char ch[]={'a','b','c','d','e','f','g'};
	//int arr[][3]={{0,1,6},{1,4,3},{4,5,6},{5,3,2},{3,0,5},{0,2,1},{2,4,6},{2,5,4},{2,3,5},{1,2,5}};
	//char ch[]={'a','b','c','d','e','f'};
	//int arr[][3]={{0,1,20},{0,4,1},{1,2,6},{1,3,4},{2,6,2},{3,5,12},{3,6,8},{4,5,15},{5,6,10}};
	//char ch[]={'a','b','c','d','e','f','g'};
	/*
	printf("���붥����:\n");
	if(scanf("%d",&num)<=0)
	{
		printf("����Ķ���������С��1\n");
		exit(-1);
	}
	nodes=(vertexNode** )malloc(num*sizeof(struct VertexNode));
	visited=(int* )malloc(num*sizeof(int));
	printf("����%d�����������:\n",num);
	for(i=0;i<num;i++)
	{
		scanf(" %c",&data);
		getchar(); 
		nodes[i]=(vertexNode* )malloc(sizeof(struct VertexNode));
		if(!nodes[i])
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		nodes[i]->data=data;
		nodes[i]->firstArc=NULL;
		visited[i]=0;
	}
	printf("���뻡��:\n");
	if(scanf("%d",&p)<0)
	{
		printf("����Ļ�������С��0\n");
		exit(-1);
	}
	*/
	printf("ͼ��-����ͼ\n");
	num=sizeof(ch)/sizeof(char);
	p=(sizeof(arr)/sizeof(int))/(sizeof(arr[0])/sizeof(int));
	nodes=(vertexNode** )malloc(num*sizeof(struct VertexNode));
	visited=(int* )malloc(num*sizeof(int));
	for(i=0;i<num;i++)
	{
		nodes[i]=(vertexNode* )malloc(sizeof(struct VertexNode));
		if(!nodes[i])
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		nodes[i]->data=ch[i];
		nodes[i]->firstArc=NULL;
		visited[i]=0;
	}
	g=(graph* )malloc(sizeof(struct Graph));
	g->vexnum=num;
	g->arcnum=p;
	for(i=0;i<p;i++)
	{
		//printf("�����%d���������������Ȩֵ:\n",i+1);
		//scanf(" %d %d %d",&a,&b,&c);
		//getchar();
		nodes=insertNode(nodes,arr[i][0],arr[i][1],arr[i][2]);
		nodes=insertNode(nodes,arr[i][1],arr[i][0],arr[i][2]);	
	}
	printf("�ڽӱ�:\n");
	for(i=0;i<num;i++)
	{
		q=nodes[i]->firstArc;	
		printf("%c->",nodes[i]->data);
		while(q)
		{
			if(q->next)
			{
				printf("%d->",q->adjvex);
			}
			else
			{
				printf("%d",q->adjvex);
			}
			q=q->next;
		}
		printf("\n");
		
	}
	dfs(sHead,nodes,g,visited);
	bfs(lQueue,nodes,g,visited);
	minSpanTree_Prim(list,nodes,g,visited);
	minSpanTree_Kruskal(arr,nodes,g,visited);
	shortPath_Dijkstra(nodes,g);
	free(q);
	free(nodes);
	free(g);
	free(sHead);
	free(lQueue);
	free(list);
	free(visited);
	return 0;
}