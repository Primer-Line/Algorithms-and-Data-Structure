#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct Graph
{
	int vexnum;
	int arcnum;
}graph;
struct ArcCell
{
	int adjvex;
	int info;
};
int main()
{
	int vexnum,arcnum,i,j,a,b,c;
	struct ArcCell** cells;
	graph* g=(graph* )malloc(sizeof(struct Graph));
	int arr[][3]={{0,5,14},{0,1,7},{0,2,9},{1,2,10},{1,3,15},{3,4,6},{2,3,11},{2,5,2},{5,4,9}};
	char ch[]={'a','b','c','d','e','f'};
	//int arr[][3]={{0,3,5},{0,1,7},{1,2,8},{1,3,9},{2,4,5},{1,4,7},{3,5,6},{3,4,15},{5,6,11},{4,6,9},{4,5,8}};
	//char ch[]={'a','b','c','d','e','f','g'};
	//printf("���붥�����ͱ���:\n");
	//scanf(" %d %d",&vexnum,&arcnum);
	vexnum=sizeof(ch)/sizeof(char);
	arcnum=(sizeof(arr)/sizeof(int))/(sizeof(arr[0])/sizeof(int));
	g->arcnum=arcnum;
	g->vexnum=vexnum;
	cells=(struct ArcCell** )malloc(vexnum*sizeof(struct ArcCell));
	for(i=0;i<vexnum;i++)
	{
		cells[i]=(struct ArcCell* )malloc(vexnum*sizeof(struct ArcCell));
		for(j=0;j<vexnum;j++)
		{
			cells[i][j].adjvex=0;
		}
	}
	for(i=0;i<vexnum;i++)
	{
		a=arr[i][0];
		b=arr[i][1];
		c=arr[i][2];
		cells[i][i].adjvex=1;
		cells[a][b].adjvex=1;
		cells[a][b].info=c;
	}
	printf("�ڽӾ���:\n");
	printf("  ");
	for(i=0;i<vexnum;i++)
	{
		printf("%d ",i);
	}
	printf("\n");
	for(i=0;i<vexnum;i++)
	{
		printf("%d ",i);
		for(j=0;j<vexnum;j++)
		{
			printf("%d ",cells[i][j].adjvex);
		}
		printf("\n");
	}
	return 0;
}