#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct Graph
{
	int vexnum;
	int arcnum;
}graph;
typedef struct ArcNode
{
	int adjvex;
	struct ArcNode* next;
	int info;
}arcNode;
typedef struct VertexNode
{
	char data;
	arcNode* firstArc;
}vertexNode;
typedef struct Stack
{
	struct Stack* next;
	vertexNode* node;
}stack;
stack* initStack();
stack* createStack();
stack* pop(stack* sHead,vertexNode** node);
stack* push(stack* sHead,vertexNode* node);
vertexNode* getStackTop(stack* sHead);
void visitStackElement(stack* sHead);
int stackEmpty(stack* sHead);
int getStackSize(stack* sHead);
stack* destoryStack(stack* sHead);
stack* clearStack(stack* sHead);
stack* initStack()
{
	stack* sHead=NULL;
	return sHead;
}
int stackEmpty(stack* sHead)
{
	if(sHead==NULL)
	{
		return 1;
	}
	return 0;

}
stack* clearStack(stack* sHead)
{
	memset(sHead,0,sizeof(sHead));
	return sHead;
}
int getStackSize(stack* sHead)
{
	/*
	Element size=0;
	stack* p=sHead;
	while(p!=NULL)
	{
		size++;
		p=p->next;
	}
	*/
	return !sHead?0:getStackSize(sHead->next)+1;
}
stack* push(stack* sHead,vertexNode* node)
{
	
	stack* p,*q=sHead;
	
	if(!sHead)
	{
		sHead=(stack* )malloc(sizeof(struct Stack));
		memset(sHead,0,sizeof(sHead));
		sHead->node=node;
		sHead->next=NULL;
		return sHead;
	}
	p=(stack* )malloc(sizeof(struct Stack));
	if(!p)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(p,0,sizeof(p));
	p->node=node;
	p->next=sHead;
	sHead=p;  
	return sHead;   
}
stack* pop(stack* sHead,vertexNode** node)
{
	stack* p=sHead;
	if(sHead==NULL)
	{
		return NULL;
	}
	/*
	while(p!=NULL)
	{
		if(p->next==NULL)
		{
			return p;
		}
		if(p->next->next=NULL)
		{
			q=p->next;
			p->next=p->next->next;
			return q;
		}
		p=p->next;
	}
	*/
	*node=sHead->node;
	sHead=sHead->next;
	//free(p);
	return sHead;
}
vertexNode* getStackTop(stack* sHead)
{
	return sHead->node;
}
stack* destoryStack(stack* sHead)
{
	free(sHead);
	sHead=NULL;
	return sHead;
}