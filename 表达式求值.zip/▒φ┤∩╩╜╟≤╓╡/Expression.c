#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include"stack.h"
#define MAX 10
typedef unsigned int UINT;
int level(char c);
int tran_num(int* arr,int len);
int caculate(stack* s);
void getResult(char,stack**,int*,int);
void expression(char* str)
{
	stack* s1=NULL;
	stack* s2=NULL;
	char ch = '#';
	void* elem;
	while(*str)
	{
		if(isdigit(*str))
		{
			push(&s1,&(*str));
			if(!*(str+1)||!isdigit(*(str+1)))push(&s1,&ch);
		}
		else
		{
			if(*str!=')')
			{
				if(stackEmpty(s2)||*str=='('||level(*str)<level(*(char*)stackTop(s2)))push(&s2,&(*str));
				else if(level(*str)>=level(*(char*)stackTop(s2)))
				{
					pop(&s2,&elem);
					push(&s1,elem);
					push(&s2,&(*str));
				}
			}
			else
			{
				while(!stackEmpty(s2)&&(*(char*)stackTop(s2))!='(')
				{
					pop(&s2,&elem);
					push(&s1,elem);
				}
				pop(&s2,&elem);
			}
		}
		str++;
	}
	while(!stackEmpty(s2))
	{
		pop(&s2,&elem);
		push(&s1,elem);
	}
	while(!stackEmpty(s1))
	{
		pop(&s1,&elem);
		push(&s2,elem);
	}
	printf("������:%d\n",caculate(s2));
	free(s2);
	s2=NULL;
}
int caculate(stack* s)
{
	stack* iStack=NULL;
	char ch;
	void* elem;
	int* num=(int* )malloc(MAX*sizeof(int));
	int nums[1000],k=0,result[100];
	int i=0;
	memset(num,0,MAX*sizeof(int));
	while(!stackEmpty(s))
	{
		pop(&s,&elem);
		ch = *(char*)elem;
		if(isdigit(ch))num[i++]=(int)ch-48;
		else if(ch=='#')
		{
			nums[k] = tran_num(num,i-1);
			push(&iStack,&nums[k++]);
			i=0;
		}
		else getResult(ch,&iStack,result,k++);
	}
	pop(&iStack,&elem);
	free(iStack);
	free(num);
	num=NULL;
	iStack=NULL;
	return *(int*)elem;
	
}
void getResult(char ch,stack** iStack,int* result,int k)
{
	void* a;
	void* b;
	int m,n;
	if(!stackEmpty(*iStack))pop(&(*iStack),&b);
	if(!stackEmpty(*iStack))pop(&(*iStack),&a);
	m = *(int*)b;
	n = *(int*)a;
	switch(ch)
	{
		case '*':
			result[k]=n*m;
			break;
		case '/':
			if(!m)
			{
				printf("��������Ϊ0\n");
				exit(-1);
			}
			result[k]=n/m;
			break;
		case '+':
			result[k]=n+m;
			break;
		case '-':
			result[k]=n-m;
			break;
	}
	push(&(*iStack),&result[k]);
}
int level(char c)
{
	int tag;
	switch(c)
	{
		case '*':
		case '/':
			tag=2;
			break;
		case '+':
		case '-':
			tag=3;
			break;
		case '(':
			tag=4;
			break;
	}
	return tag;
}
int tran_num(int* arr,int len)
{
    int i=-1,num=0;
	if(len==0)return arr[len];
	while(i++<len)num=num*10+arr[i];
	return num;
}
int main()
{
	char* str="1+2*3-6+18*2+2+3*(2+3*6)+12-4+6*6";//143
	//+ - + + + + - + * # 6 # 6 # 4 # 2 1 * + * # 6 # 3 # 2 # 3 # 2 * # 2 # 8 1 # 6 * # 3 # 2 # 1
	printf("����ʽ:%s\n",str);
	expression(str);
	return 0;
}
