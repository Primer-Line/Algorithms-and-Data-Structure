typedef void* elemType;
typedef int Element;
typedef struct Stack
{
	elemType elem;
	struct Stack* next;
}stack;
void pop(stack** sHead,elemType*);
void push(stack** sHead,const elemType);
elemType stackTop(stack* sHead);
void visitStackElement(stack* sHead);
int stackEmpty(stack* sHead);
int getStackSize(stack* sHead);
void destoryStack(stack** sHead);
int stackEmpty(stack* sHead)
{
	return sHead == NULL;
}
int getStackSize(stack* sHead)
{
	return !sHead?0:getStackSize(sHead->next)+1;
}
void push(stack** sHead,elemType elem)
{	
	stack* p,*q=(*sHead);
	if(!(*sHead))
	{
		(*sHead)=(stack* )malloc(sizeof(struct Stack));
		if(!(*sHead))
		{
			printf("�ڴ����ʧ��\n");
			exit(-1);
		}
		memset((*sHead),0,sizeof((*sHead)));
		(*sHead)->elem = elem;
		(*sHead)->next=NULL;
		return;
	}
	p=(stack* )malloc(sizeof(struct Stack));
	if(!p)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(p,0,sizeof(p));
	p->elem=elem;
	p->next=(*sHead);
	(*sHead)=p;   
}
void pop(stack** sHead,elemType* elem)
{
	*elem=(*sHead)->elem;
	(*sHead)=(*sHead)->next;
}
elemType stackTop(stack* sHead)
{
	return sHead->elem;
}
void destoryStack(stack** sHead)
{
	stack* p;
	while(*sHead)
	{
		p = (*sHead)->next;
		free(*sHead);
		*sHead = p;
	}
}
