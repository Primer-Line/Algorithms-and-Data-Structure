#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stack.h"
typedef unsigned int UINT;
UINT match(char* str)
{
	stack* s=NULL;
	void* elem;
	char ch;
	while(*str)
	{
		if(*str=='('||*str=='['||*str=='{')push(&s,&(*str));
		if(!stackEmpty(s))
		{
			stackTop(s,&elem);
			ch=*(char*)elem;
		}
		if(*str==')')
		{
			if(stackEmpty(s)||ch!='(')return 0;
			pop(&s,&elem);
		}
		if(*str=='}')
		{
			if(stackEmpty(s)||ch!='{')return 0;
			pop(&s,&elem);
		}
		if(*str==']')
		{
			if(stackEmpty(s)||ch!='[')return 0;
			pop(&s,&elem);
		}
		str++;
	}
	if(!stackEmpty(s))return 0;
	return 1;
}
int main()
{
	char* str="[({})[]";
	if(match(str))printf("����ƥ��\n");
	else printf("���Ų�ƥ��\n");
	return 0;
}