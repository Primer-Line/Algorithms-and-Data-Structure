#define MAX_LENGTH 128
typedef char dataType;
typedef void* elemType;
typedef struct HuffmanTree
{
	dataType data;
	unsigned int weight;
	struct HuffmanTree* left;
	struct HuffmanTree* right;
	struct HuffmanTree* parent;
}Tree,*huffmanTree;
typedef struct Heap
{
	elemType* arr;
	int current_length;
	int max_length;
}heap;
void adjustHeap(struct Heap* heap);
//��ʼ����
void initHeap(struct Heap** heap)
{
	(*heap) = (struct Heap* )malloc(sizeof(struct Heap));
	(*heap)->arr=(elemType* )malloc(sizeof(elemType)*MAX_LENGTH);
	(*heap)->current_length=0;
	(*heap)->max_length=MAX_LENGTH;
}

int cmp(const void* a,const void* b)
{
	Tree* m = (Tree*)a,*n = (Tree*)b;
	if(m->weight<n->weight)return -1;
	if(m->weight==n->weight)return 0;
	return 1;
}

void insertHeap(struct Heap** heap,elemType elem)
{
	if((*heap)->current_length==(*heap)->max_length)
	{
		(*heap)->max_length += (*heap)->max_length;
		realloc((*heap)->arr,(*heap)->max_length*sizeof(elemType));
	}
	(*heap)->arr[(*heap)->current_length++]=elem;
	adjustHeap(*heap);

}
void swap(elemType* a,elemType* b)
{
	elemType temp=*a;
	*a=*b;
	*b=temp;
}
void deleteHeap(struct Heap** heap,elemType* val)
{
	*val=(*heap)->arr[0];
	swap(&((*heap)->arr[0]),&((*heap)->arr[--((*heap)->current_length)]));
	adjustHeap(*heap);
}
//������
void adjustHeap(struct Heap* heap)
{
	int size = heap->current_length,i,k = size/2-1;
	elemType temp=NULL;
	if(size<=1)return;
	for(i = k;i>=0;i--)
	{
		temp = i==k&&2*i+3!=size?heap->arr[2*i+1]:(cmp(heap->arr[2*i+1],heap->arr[2*i+2])==-1?heap->arr[2*i+1]:heap->arr[2*i+2]);
		if(cmp(temp,heap->arr[i])==-1)swap(temp==heap->arr[2*i+1]?&heap->arr[2*i+1]:&heap->arr[2*i+2],&heap->arr[i]);//����ԭ���Ƚ� �ø��ӱ������ܻ���� �ⲿ��������ָ��Ƚ�
	}
	for(i = 1;i<=k;i++)
	{
		temp = i==k&&2*i+3!=size?heap->arr[2*i+1]:(cmp(heap->arr[2*i+1],heap->arr[2*i+2])==-1?heap->arr[2*i+1]:heap->arr[2*i+2]);
		if(cmp(temp,heap->arr[i])==-1)swap(temp==heap->arr[2*i+1]?&heap->arr[2*i+1]:&heap->arr[2*i+2],&heap->arr[i]);
	}
	
}
