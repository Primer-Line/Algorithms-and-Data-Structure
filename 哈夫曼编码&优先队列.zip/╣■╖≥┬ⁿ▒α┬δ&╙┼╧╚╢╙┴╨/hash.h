#define LEN 20
typedef unsigned int UINT;
typedef UINT (*company)(const void* a,const void* b);
typedef struct Hash
{
	void* key;
	void* val;
	struct LinkedList* head;
}hash;
typedef struct LinkedList
{
	void* key;
	void* val;
	struct LinkedList* next;
}linkeList;
//hash����
UINT hashCode(void* key)
{
	return ((((unsigned long int)key & 0x3f3f6) >> 16) ^ 0xff) % LEN;
}
//���Ŷ�ַ��
void createHash(hash*** hashArr)
{
	*hashArr= (struct Hash**) malloc(sizeof(struct Hash*)*LEN);
	memset(*hashArr,0x00,sizeof(struct Hash*)*LEN);
}
//ֱ������ַ��
void initHash(hash*** hashArr)
{
	struct LinkedList* p=NULL;
	*hashArr= (struct Hash**) malloc(sizeof(struct Hash*)*LEN);
	memset(*hashArr,0x00,sizeof(struct Hash*)*LEN);
}
//����key��Ӧ��val �ɹ�����1 ʧ�ܷ���0
void* searchValue(hash** hashArr,void* key,company cmp)//void* p = q;p = h;
{
	UINT index=hashCode(key);
	struct LinkedList* p;
	if(!hashArr[index])return NULL;
	p = hashArr[index]->head;
	if(!p)return NULL;
	while(p!=NULL&&!(*cmp)(p->key,key))p=p->next;
	if(p)return p->val;
	return NULL;
}
//����ַ�� ͷ�巨
void insertHash(hash*** hashArr,void* key,void* val)
{
	UINT index=hashCode(key);
	struct LinkedList* p,*q;
	if(!(*hashArr)[index])
	{
		(*hashArr)[index] = (struct Hash*)malloc(sizeof(struct Hash));
		if(!(*hashArr)[index])exit(-1);
		(*hashArr)[index]->head = NULL;
	}
	p = ((*hashArr)[index])->head;
	//if(searchValue(hashArr,key,&elem))return;
	q = (struct LinkedList*)malloc(sizeof(struct LinkedList));
	if(!q)exit(-1);
	q->key = key;
	q->val = val;
	q->next = p;
	((*hashArr)[index])->head = q;
}
UINT findValue(void* key,hash** hashArr,void** val)
{
	UINT index=hashCode(key);
	while(hashArr[index]&&hashArr[index]->key!=key)index++;
	if(hashArr[index])
	{
		*val = hashArr[index]->val;
		return 1;
	}
	return 0;
}
//��������
void destoryLinkedList(linkeList** list)
{
	linkeList* p;
	while(*list)
	{
		p = (*list)->next;
		free(*list);
		*list = p;
	}
}
//���ٹ�ϣ��
void destroyHash(struct Hash*** hashArr)
{
	UINT i;
	for(i=0;i<LEN;i++)
	{
		if((*hashArr)[i])
		{
			destoryLinkedList(&((*hashArr)[i]->head));
			free((*hashArr)[i]);
		}
	}
	free(*hashArr);
}

