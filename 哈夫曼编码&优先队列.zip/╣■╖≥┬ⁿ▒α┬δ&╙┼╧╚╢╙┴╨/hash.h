#define LEN 16
typedef unsigned int UINT;
typedef UINT (*company)(const void* a,const void* b);
//ɢ��
typedef struct Hash
{
	void* key;
	void* val;
	struct LinkedList* head;
}hash;
//����
typedef struct LinkedList
{
	void* key;
	void* val;
	struct LinkedList* next;
}linkeList;
//hash����
UINT hashCode(void* key)
{
	return ((((unsigned long int)key & 0x3f3f6) >> 16) ^ 0xff) & (LEN - 1);//key��ͬ ��ϣֵ������ͬ
}
//��ʼ��ɢ�б�
void initHash(hash*** hashArr)
{
	*hashArr= (struct Hash**) malloc(sizeof(struct Hash*)*LEN);
	if(!*hashArr)exit(-1);
	memset(*hashArr,0x00,sizeof(struct Hash*)*LEN);
}
//����key��Ӧ��val �ɹ�����val ʧ�ܷ���NULL
void* searchValue(hash** hashArr,void* key,company cmp)//void* p = q;p = h;
{
	UINT index=hashCode(key);
	struct LinkedList* p;
	if(!hashArr[index])return NULL;
	p = hashArr[index]->head;
	if(!p)return NULL;
	while(p!=NULL&&!(*cmp)(p->key,key))p=p->next;
	return p ? p->val : NULL;
}
//����ַ�� ͷ�巨
void insertHash(hash*** hashArr,void* key,void* val,company cmp)
{
	UINT index=hashCode(key);
	struct LinkedList* p,*q,*h;
	if(!(*hashArr)[index])
	{
		(*hashArr)[index] = (struct Hash*)malloc(sizeof(struct Hash));
		if(!(*hashArr)[index])exit(-1);
		(*hashArr)[index]->head = NULL;
	}
	p = ((*hashArr)[index])->head;
	h = p;
	while(h&&!(*cmp)(h->key,key))h=h->next;//ȷ��key��Ψһ��
	if(h)
	{
		h->val = val;//����val
		return;
	}
	q = (struct LinkedList*)malloc(sizeof(struct LinkedList));
	if(!q)exit(-1);
	q->key = key;
	q->val = val;
	q->next = p;
	((*hashArr)[index])->head = q;
}
//ֱ�Ӷ�ַ��
void insert_Hash(hash*** hashArr,void* key,void* val,company cmp)
{
	UINT index=hashCode(key),k;
	if(!(*hashArr)[index])
	{
		(*hashArr)[index] = (struct Hash*)malloc(sizeof(struct Hash));
		if(!(*hashArr)[index])exit(-1);
		(*hashArr)[index]->key = key;//memcpy to from
		(*hashArr)[index]->val = val;
		return;
	}
	k = index+1;
	while(k<LEN&&(*hashArr)[k])k++;//ѭ������
	if(k<LEN)
	{
		(*hashArr)[k] = (struct Hash*)malloc(sizeof(struct Hash));
		if(!(*hashArr)[k])exit(-1);
		(*hashArr)[k]->key = key;
		(*hashArr)[k]->val = val;
	}
}
//����key��Ӧ��val �ɹ�����1 ʧ�ܷ���0
UINT findValue(void* key,hash** hashArr,void** val,company cmp)
{
	UINT index=hashCode(key),k=index+1;
	while(k<LEN&&hashArr[k]&&!(*cmp)(hashArr[k]->key,key))k++;
	if(k<LEN&&hashArr[k]&&(*cmp)(hashArr[k]->key,key))
	{
		*val = hashArr[index]->val;
		return 1;
	}
	return 0;
}
//��������
void destoryLinkedList(linkeList** list)
{
	linkeList* p;
	while(*list)
	{
		p = (*list)->next;
		free(*list);
		*list = p;
	}
}
//���ٹ�ϣ��
void destroyHash(struct Hash*** hashArr)
{
	UINT i;
	for(i=0;i<LEN;i++)
	{
		if((*hashArr)[i])
		{
			destoryLinkedList(&((*hashArr)[i]->head));
			free((*hashArr)[i]);
		}
	}
	free(*hashArr);
}

