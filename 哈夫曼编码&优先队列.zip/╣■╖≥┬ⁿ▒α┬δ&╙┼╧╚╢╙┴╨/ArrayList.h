#define DEFALUT_MAX_LENGTH 20	
struct Frequency
{
	char data;
	unsigned int frequency;
};
typedef struct ArrayList
{
	struct Frequency** arr;
	unsigned int max_length;
	unsigned int current_length;
}List;
void initArrayList(struct ArrayList** list)
{
	(*list)=(struct ArrayList* )malloc(sizeof(struct ArrayList));
	(*list)->arr=(struct Frequency** )malloc(DEFALUT_MAX_LENGTH*sizeof(struct Frequency* ));
	(*list)->max_length=DEFALUT_MAX_LENGTH;
	(*list)->current_length=0;
}
void add(struct ArrayList** list,char data,unsigned int _frequency)
{
	struct Frequency* frequency=(struct Frequency* )malloc(sizeof(struct Frequency));
	if(!frequency)exit(-1);
	frequency->data=data;
	frequency->frequency=_frequency;
	if((*list)->current_length==(*list)->max_length)
	{
		(*list)->max_length+=(*list)->max_length;
		realloc((*list)->arr,(*list)->max_length*sizeof(struct Frequency*));
	}
	(*list)->arr[(*list)->current_length++]=frequency;
}