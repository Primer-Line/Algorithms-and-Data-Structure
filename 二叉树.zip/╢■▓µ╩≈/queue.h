typedef int dataType;
struct Queue
{
	struct Queue* next;
	void* elem;
};
typedef struct Queue queue;
typedef struct LinkQueue
{
	queue* front;
	queue* rear;
}linkQueue;
void initQueue(linkQueue**);
void visitQueue(linkQueue* queue);
void queueTop(linkQueue* queue,void** elem);
void clearQueue(linkQueue** queue);
void enQueue(linkQueue** queue,void* elem);
void deQueue(linkQueue** queue,void**);
dataType queueEmpty(linkQueue* queue);
dataType getQueueSize(linkQueue* queue);
void initQueue(linkQueue** queue)
{
	*queue=(linkQueue*)malloc(sizeof(struct LinkQueue));
	if(!(*queue))
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	(*queue)->front=(*queue)->rear=(struct Queue* )malloc(sizeof(struct Queue));
}
dataType getQueueSize(linkQueue* lQueue)
{
	queue* q=lQueue->front,*p=lQueue->rear;
	dataType length=0;
	while(q!=p)
	{
		q=q->next;		
		length++;
	}
	return length;
}
dataType queueEmpty(linkQueue* queue)
{
	return queue->front == queue->rear;
}
void queueTop(linkQueue* queue, void** elem)
{
	*elem = queue->front->next->elem;
}
void enQueue(linkQueue** lQueue,void* elem)
{
	queue* q=NULL;
	q=(queue* )malloc(sizeof(struct Queue));
	if(!q)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	q->elem = elem;
	(*lQueue)->rear->next=q;
	(*lQueue)->rear=q;
}
void deQueue(linkQueue** lQueue,void** elem)
{
	queue* q=(*lQueue)->front;
	if(q->next==(*lQueue)->rear)
	{
		*elem=(*lQueue)->rear->elem;
		(*lQueue)->rear=(*lQueue)->front;
		return;
	}
	*elem=(*lQueue)->front->next->elem;
	(*lQueue)->front->next=(*lQueue)->front->next->next;
}
void destoryQueue(linkQueue** lQueue)
{
	queue* q,*p = (*lQueue)->rear;
	while((*lQueue)->front!=p)
	{
		q = (*lQueue)->front->next;
		free((*lQueue)->front);
		(*lQueue)->front = q;
	}
	free((*lQueue)->front);
}