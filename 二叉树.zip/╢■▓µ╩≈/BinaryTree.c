#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"queue.h"
#include"stack.h"
#define ERROR -1
#define TRUR 1
#define FALSE 0
typedef char Element;
typedef struct BinaryTree
{
	Element data;
	struct BinaryTree* Lchild;
	struct BinaryTree* Rchild;
	struct BinaryTree* parent;
} Tree,*TreeNode;
void createTree(Tree** Root);
void preOrder(Tree* Root);
void inOrder(Tree* Root);
void laOrder(Tree* Root);
void levelOrder(Tree* Root);
int getTreeHeight(Tree* Root);
int getNodeCount(Tree* Root);
void createTree(Tree** Root)
{
	Element ch;
	printf("input node's data('#' is end):\n");
	scanf("%c",&ch);
	getchar();
	if(ch=='#')
	{
		*Root=NULL;
		return;
	}
	*Root=(Tree* )malloc(sizeof(struct BinaryTree));
	(*Root)->data=ch;
	createTree(&((*Root)->Lchild));
	createTree(&((*Root)->Rchild));
}
void create_Tree(Tree** Root)
{
	Tree* node,*node1,*node2,*root;
	linkQueue* lQueue=NULL;
	Element ch,data;
	initQueue(&lQueue);
	printf("input Root's data('#' is end):\n");
	scanf("%c",&ch);
	getchar();
	if(ch!='#')
	{
		*Root=(Tree* )malloc(sizeof(struct BinaryTree));
		(*Root)->data=ch;
		root=(*Root);
		enQueue(&lQueue,root);
		while(!queueEmpty(lQueue))
		{
			deQueue(&lQueue,&node);
			node->Lchild=NULL;
		    node->Rchild=NULL;
			printf("input %c's Lnode's data and Rnode's data('#' is end):\n",node->data);
	        scanf("%c %c",&ch,&data);
	        getchar();
			if(ch!='#')
			{
				node1=(Tree* )malloc(sizeof(struct BinaryTree));
				node1->data=ch;
				node->Lchild=node1;
				node1->parent=node;
				enQueue(&lQueue,node->Lchild);
			}
			if(data!='#')
			{
				node2=(Tree* )malloc(sizeof(struct BinaryTree));
				node2->data=data;
				node->Rchild=node2;
				node2->parent=node;
				enQueue(&lQueue,node->Rchild);
			}
		} 
	}
}
void levelOrder(Tree* root)
{
	Tree* node,*Root=root;
	linkQueue* lQueue = NULL;
	initQueue(&lQueue);
	if(Root)
	{
		enQueue(&lQueue,Root);
		while(!queueEmpty(lQueue))
		{
			deQueue(&lQueue,&node);
			printf("%c",node->data);
			if(node->Lchild)
			{
				enQueue(&lQueue,node->Lchild);
			}
			if(node->Rchild)
			{
				enQueue(&lQueue,node->Rchild);
			}
		} 
		printf("\n");
	}
}
int getTree_Height(Tree* root)
{
	Tree* node,*Root=root;
	int length = 0;
	linkQueue* lQueue = NULL;
	if(!Root)return 0;
	initQueue(&lQueue);
	enQueue(&lQueue,(void*)Root);
	while(!queueEmpty(lQueue))
	{
		deQueue(&lQueue,&node);
		if(node->Lchild)
		{
			enQueue(&lQueue,node->Lchild);
		}
		if(node->Rchild)
		{
			enQueue(&lQueue,node->Rchild);
		}
	} 
	while(node!=Root)
	{
		length++;
		node=node->parent;
	}
	return length+1;
}
void preOrder(Tree* root)
{
	Tree* node,*Root=root;
	if(Root)
	{
		stack* sHead=NULL;
		push(&sHead,Root);
		while(!stackEmpty(sHead))
		{
			pop(&sHead,&node);
			printf("%c",node->data);
			if(node->Rchild)
			{
				push(&sHead,node->Rchild);
			}
			if(node->Lchild)
			{
				push(&sHead,node->Lchild);
			}
		} 
		printf("\n");
	}
}

void inOrder(Tree* Root)
{
	Tree*node,*p=Root;
	if(p)
	{
		stack* sHead=NULL;
		push(&sHead,p);
		while(!stackEmpty(sHead))
		{
			while(p->Lchild)
			{
				push(&sHead,p->Lchild);
				p=p->Lchild;
			}
			while(!stackEmpty(sHead))
			{	
				pop(&sHead,&node);
				printf("%c",node->data);
				if(node->Rchild)
				{
					p=node->Rchild;
					push(&sHead,p);
					break;
				}
			}
			
		} 	
		printf("\n");
	
	}
}
void laOrder(Tree* Root)
{
	Tree* p=Root,*node,*q;
	if(p)
	{
		stack* sHead=NULL;
		push(&sHead,p);
		while(!stackEmpty(sHead))
		{
			while(p->Lchild)
			{
				push(&sHead,p->Lchild);
				p=p->Lchild;
			}
			while(!stackEmpty(sHead))
			{
				pop(&sHead,&node);
				if(!node->Rchild)
				{
					printf("%c",node->data);
				}
				else
				{
					if(node->Rchild==q)
					{
						q=node;
						printf("%c",node->data);
					}
					else
					{
						push(&sHead,node);
						p=node->Rchild;
						push(&sHead,p);
						q=p;
						break;
					}
				}
				
			}	
			
		} 
		printf("\n");
	
	}
}
int getTreeHeight(Tree* Root)
{
	if(!Root)return 0;
	return getTreeHeight(Root->Lchild)>getTreeHeight(Root->Rchild)?getTreeHeight(Root->Lchild)+1:getTreeHeight(Root->Rchild)+1;
}
int getNodeCount(Tree* Root)
{
	if(!Root)return 0;
	return getNodeCount(Root->Lchild)+getNodeCount(Root->Rchild)+1;
}
int getNode_Count(Tree* Root)
{
	Tree* node;
	linkQueue* lQueue=NULL;
	int count = 0;
	initQueue(&lQueue);
	if(Root)
	{
		enQueue(&lQueue,Root);
		while(!queueEmpty(lQueue))
		{
			deQueue(&lQueue,&node);
			count++;
			if(node->Lchild)
			{
				enQueue(&lQueue,node->Lchild);
			}
			if(node->Rchild)
			{
				enQueue(&lQueue,node->Rchild);
			}
		} 
	}
	return count;
}
int main()
{
	Tree* Root=NULL;
	create_Tree(&Root);
	printf("Tree's preOrder:\n");
	preOrder(Root);
	printf("Tree's inOrder:\n");
	inOrder(Root);
	printf("Tree's laOrder:\n");
	laOrder(Root);
	printf("Tree's levelOrder:\n");
	levelOrder(Root);
	printf("1:Tree's Height is %d\n",getTreeHeight(Root));
	printf("2:Tree's Height is %d\n",getTree_Height(Root));
	printf("1:Tree's NodeCount is %d\n",getNode_Count(Root));
	printf("2:Tree's NodeCount is %d\n",getNodeCount(Root));
	return 0;
}