#include"Heap.h"
int topoSort(Graph* g,VextexNode** vextexNode,int** arr)
{
	int* inGree=(int* )malloc(sizeof(int)*g->vexnum),*deGree=(int* )malloc(sizeof(int)*g->vexnum),i,count=0;
	struct LinkQueue* queue=NULL;
	VextexNode* node=NULL;
	initQueue(&queue);
	memset(inGree,0,sizeof(int)*g->vexnum);
	memset(deGree,0,sizeof(int)*g->vexnum);
	for(i=0;i<g->vexnum-1;i++)
	{
		inGree[arr[i][1]]++;
		deGree[arr[i][0]]++;
	}
	for(i=0;i<g->vexnum;i++)
	{
		if(!inGree[i])
		{
			enQueue(&queue,vextexNode[i]);
		}
	}
	while(!queueEmpty(queue))
	{
		deQueue(&queue,&node);
		count++;
		ArcNode* p=node->firstOut;
		while(p)
		{
			if(!--inGree[p->headVex])
			{
				enQueue(&queue,vextexNode[p->headVex]);
			}
			p=p->hLink;
		}

	}
	if(count<g->vexnum)
	{
		/*
		printf("����{");
		for(i=0;i<g->vexnum;i++)
		{
			if(deGree[i]>0)			{
				printf("%c",vextexNode[i]->data);
			}
		}
		printf("}���ɻ�\n");
		*/
		return 0;
	}
	return 1;
}
void MST(Graph* g,VextexNode** vextexNode)
{
	int num=0,i,weight,sum=0;
	Heap** heap=(Heap** )malloc(sizeof(Heap* )*(g->vexnum-1));
	int** arr=(int** )malloc(sizeof(int* )*(g->vexnum-1)),index=0;
	ArcNode* p;
	for(i=1;i<g->vexnum;i++)
	{
		if(vextexNode[i]->firstIn)
		{
			initHeap(&heap[i]);
			p=vextexNode[i]->firstIn;
			while(p)
			{
				insertHeap(&heap[i],p);
				p=p->tLink;
			}
			weight=heap[i]->arr[0]->info;
			arr[index]=(int* )malloc(sizeof(int)*3);
			arr[index][0]=heap[i]->arr[0]->tailVex;
			arr[index][1]=i;
			arr[index++][2]=weight;
			num++;
		}
	}
	if(num<g->vexnum-1)
	{
		printf("����ͼ�в�������С������\n");
		return;
	}
	if(!topoSort(g,vextexNode,arr))
	{
		printf("���ڻ�·\n");
	}
	else
	{
		printf("������С������\n");
	}

}
void findMaxCircle(Graph* g,VextexNode** vextexNode)
{
	
}
int main()
{
	//register int k = 0;
	int arr[][3]={{1,0,3},{2,1,2},{3,2,5},{3,4,4},{5,0,1},{4,0,7},{5,1,6},{5,4,8},{3,5,10},{2,5,7},{1,3,11}};
	//int arr[][3]={{0,1,4},{1,2,7},{3,2,9}};
	//int arr[][3]={{5,2,5},{5,0,6},{4,0,8},{4,1,3},{2,3,4},{3,1,7}},a=1;
	char c[]={'a','b','c','d','e','f'};
	//char c[]={'a','b','c','d'};
	int len=sizeof(arr)/(3*sizeof(int)),size=sizeof(c)/sizeof(char);
	Graph* g=NULL;
	VextexNode** vextexNode=NULL;
	createGraph(arr,len,c,size,&g,&vextexNode);
	showGraphList(g,vextexNode);
	DFS(g,vextexNode);
	BFS(g,vextexNode);
	topologicalSortting(g,vextexNode);
	topoLogicalSort(g,vextexNode);
	MST(g,vextexNode);
	return 0; 
}