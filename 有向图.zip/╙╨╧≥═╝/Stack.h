typedef struct VextexNode Element;
typedef struct Stack
{
	struct Stack* next;
	Element* data;
}stack;
stack* createStack();
void pop(stack** sHead,Element**);
void push(stack** sHead,Element* data);
Element* getStackTop(stack* sHead);
void visitStackElement(stack* sHead);
int stackEmpty(stack* sHead);
int getStackSize(stack* sHead);
stack* destoryStack(stack* sHead);
stack* clearStack(stack* sHead);
int stackEmpty(stack* sHead)
{
	if(sHead==NULL)
	{
		return 1;
	}
	return 0;

}
stack* clearStack(stack* sHead)
{
	memset(sHead,0,sizeof(sHead));
	return sHead;
}
int getStackSize(stack* sHead)
{
	/*
	Element size=0;
	stack* p=sHead;
	while(p!=NULL)
	{
		size++;
		p=p->next;
	}
	*/
	return !sHead?0:getStackSize(sHead->next)+1;
}
void push(stack** sHead,Element* data)
{
	
	stack* p,*q=(*sHead);
	
	if(!(*sHead))
	{
		(*sHead)=(stack* )malloc(sizeof(struct Stack));
		memset((*sHead),0,sizeof((*sHead)));
		(*sHead)->data=data;
		(*sHead)->next=NULL;
		return;
	}
	p=(stack* )malloc(sizeof(struct Stack));
	if(!p)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	memset(p,0,sizeof(p));
	p->data=data;
	p->next=(*sHead);
	(*sHead)=p;  
}
void pop(stack** sHead,Element** data)
{
	/*
	while(p!=NULL)
	{
		if(p->next==NULL)
		{
			return p;
		}
		if(p->next->next=NULL)
		{
			q=p->next;
			p->next=p->next->next;
			return q;
		}
		p=p->next;
	}
	*/
	*data=(*sHead)->data;
	*sHead=(*sHead)->next;
	//free(p);
	//return sHead;
}
Element* getStackTop(stack* sHead)
{
	return sHead->data;
}
stack* destoryStack(stack* sHead)
{
	free(sHead);
	sHead=NULL;
	return sHead;
}
/*
Element main()
{
	stack* sHead=initStack();
	stack* p;
	int i;
	printf("������ջԪ������:\n");
	for (i=1;i<=9;i++)
	{
		printf("%d ",i);
		sHead=push(sHead,i);
	}
	printf("\n");
	if(stackEmpty(sHead))
	{
		printf("��ջʧ��\n");
		exit(-1);
	}
	printf("ջ����:%d\n",getStackSize(sHead));
	printf("����ջԪ������:\n");
	visitStackElement(sHead);
	printf("���ջԪ��:\n");
	sHead=clearStack(sHead);
	printf("ջ����:%d\n",getStackSize(sHead));
	visitStackElement(sHead);
	p=pop(sHead);
	if(p)
	{
		printf("%d\n",p->data);
	}
	else
	{
		printf("ջ��\n");
	}
	return 0;
}
*/