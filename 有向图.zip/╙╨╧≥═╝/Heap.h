#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"Stack.h"
#include"Queue.h"
#define MAX_LENGTH 20
enum
{
IN=0,
OUT=1
};
typedef struct Graph
{
	int arcnum;
	int vexnum;
}Graph;
typedef struct ArcNode
{
	int headVex;
	int tailVex;
	struct ArcNode* hLink;
	struct ArcNode* tLink;
	int info;
}ArcNode;
typedef struct VextexNode
{
	int data;
	struct ArcNode* firstIn;//tLink
	struct ArcNode* firstOut;//hLink

}VextexNode,*VNode;
typedef struct Heap
{
	ArcNode** arr;
	int current_length;
	int max_length;
}heap;
void adjustHeap(ArcNode** arcNode,int size);
void initHeap(struct Heap** heap)
{
	(*heap) = (struct Heap* )malloc(sizeof(struct Heap));
	(*heap)->arr=(ArcNode** )malloc(sizeof(ArcNode*)*MAX_LENGTH);
	(*heap)->current_length=0;
	(*heap)->max_length=MAX_LENGTH;
}
void insertHeap(struct Heap** heap,ArcNode* arcNode)
{
	ArcNode** arr;
	if((*heap)->current_length==(*heap)->max_length)
	{
		(*heap)->max_length+=(*heap)->max_length;
		arr=(ArcNode** )malloc(sizeof(ArcNode*)*((*heap)->max_length));
		arr=(*heap)->arr;
		arr[(*heap)->current_length++]=arcNode;
		(*heap)->arr=arr;
	}
	else
	{
		(*heap)->arr[(*heap)->current_length++]=arcNode;
	}
	adjustHeap((*heap)->arr,(*heap)->current_length);

}
void swap(ArcNode** a,ArcNode** b)
{
	ArcNode* temp=(*a);
	(*a)=(*b);
	(*b)=temp;
}
void deleteHeap(struct Heap** heap)
{
	swap(&((*heap)->arr[0]),&((*heap)->arr[(*heap)->current_length-1]));
	(*heap)->current_length--;
	adjustHeap((*heap)->arr,(*heap)->current_length);
}
void adjustHeap(ArcNode** arcNode,int size)
{
	int i;
	ArcNode* temp;
	if(size==1)return;
	for(i = size/2-1;i>=0;i--)
	{
		if(i == size/2-1&&(2*i)!=size-3)
		{
			temp=arcNode[2*i+1];
		}
		else
		{
			temp=arcNode[2*i+1]->info<arcNode[2*i+2]->info?arcNode[2*i+1]:arcNode[2*i+2];
		}
		if(temp->info<arcNode[i]->info)
		{
			swap(temp==arcNode[2*i+1]?(&arcNode[2*i+1]):(&arcNode[2*i+2]),&arcNode[i]);
		}
	}
	for(i = 0;i<=size/2-1;i++)
	{
		if(i == size/2-1&&(2*i)!=size-3)
		{
			temp=arcNode[2*i+1];
		}
		else
		{
			temp=arcNode[2*i+1]->info<arcNode[2*i+2]->info?arcNode[2*i+1]:arcNode[2*i+2];
		}
		if(temp->info<arcNode[i]->info)
		{
			swap(temp==arcNode[2*i+1]?(&arcNode[2*i+1]):(&arcNode[2*i+2]),&arcNode[i]);
		}
	}
}
void heapSort(struct Heap* heap)
{
	int n = heap->current_length,i;
	while(--n>0)
	{
		swap(&(heap->arr[0]),&(heap->arr[n]));
		adjustHeap(heap->arr,n);
	}
	for(i=0;i<heap->current_length;i++)
	{
		printf("%d ",heap->arr[i]->info);
	}
	printf("\n");

}
void createArcNode(ArcNode** node,int adjvex,int info,int type)
{
}
void createGraph(int arr[][3],int len,char* c,int size,Graph** g,VextexNode*** vextexNode)
{
	int i;
	struct ArcNode* p,*node;
	(*g)=(Graph* )malloc(sizeof(Graph));
	(*g)->vexnum=size;
	(*g)->arcnum=len;
	(*vextexNode)=(struct VextexNode** )malloc(size*sizeof(struct VextexNode*));
	memset((*vextexNode),0x00,size*sizeof(VextexNode*));
	for(i=0;i<len;i++)
	{
		if(!(*vextexNode)[arr[i][0]])
		{
			(*vextexNode)[arr[i][0]]=(VextexNode* )malloc(sizeof(VextexNode));
			(*vextexNode)[arr[i][0]]->data=c[arr[i][0]];
			(*vextexNode)[arr[i][0]]->firstIn=NULL;
			(*vextexNode)[arr[i][0]]->firstOut=NULL;
		}
		if(!(*vextexNode)[arr[i][0]]->firstOut)
		{
			(*vextexNode)[arr[i][0]]->firstOut=(struct ArcNode* )malloc(sizeof(struct ArcNode));
			(*vextexNode)[arr[i][0]]->firstOut->headVex=arr[i][1];
			(*vextexNode)[arr[i][0]]->firstOut->info=arr[i][2];
			(*vextexNode)[arr[i][0]]->firstOut->hLink=NULL;
		}
		else
		{
			node=(struct ArcNode* )malloc(sizeof(struct ArcNode));
			node->info=arr[i][2];
			node->headVex=arr[i][1];
			p=(*vextexNode)[arr[i][0]]->firstOut;
			if(arr[i][1]<p->headVex)
			{
				node->hLink=p;
				(*vextexNode)[arr[i][0]]->firstOut=node;
			}
			else
			{
				while(!(!p->hLink||p->headVex<arr[i][1]&&p->hLink->headVex>arr[i][1]))
				{
					p=p->hLink;
				}
				node->hLink=p->hLink;
				p->hLink=node;
			}
		}
		if(!(*vextexNode)[arr[i][1]])
		{
			(*vextexNode)[arr[i][1]]=(VextexNode* )malloc(sizeof(VextexNode));
			(*vextexNode)[arr[i][1]]->data=c[arr[i][1]];
			(*vextexNode)[arr[i][1]]->firstIn=NULL;
			(*vextexNode)[arr[i][1]]->firstOut=NULL;
		}
		if(!(*vextexNode)[arr[i][1]]->firstIn)
		{
			(*vextexNode)[arr[i][1]]->firstIn=(struct ArcNode* )malloc(sizeof(struct ArcNode));
			(*vextexNode)[arr[i][1]]->firstIn->tailVex=arr[i][0];
			(*vextexNode)[arr[i][1]]->firstIn->info=arr[i][2];
			(*vextexNode)[arr[i][1]]->firstIn->tLink=NULL;
		}
		else
		{
			node=(struct ArcNode* )malloc(sizeof(struct ArcNode));
			node->info=arr[i][2];
			node->tailVex=arr[i][0];
			p=(*vextexNode)[arr[i][1]]->firstIn;
			if(arr[i][0]<p->tailVex)
			{
				node->tLink=p;
				(*vextexNode)[arr[i][1]]->firstIn=node;
			}
			else
			{
				while(!(!p->tLink||p->tailVex<arr[i][0]&&p->tLink->tailVex>arr[i][0]))
				{
					p=p->tLink;
				}
				node->tLink=p->tLink;
				p->tLink=node;
			}
		}
	}
}
void showGraphList(Graph* g,VextexNode** vextexNode)
{
	int i;
	struct ArcNode* in_node,*out_node;
	for(i=0;i<g->vexnum;i++)
	{
		in_node=vextexNode[i]->firstIn;
		out_node=vextexNode[i]->firstOut;
		printf("%c ",vextexNode[i]->data);
		printf("���: %d->",i);
		while(in_node)
		{
			printf("%d->", in_node->tailVex);
			in_node=in_node->tLink;
		}
		printf("NULL\n");
		printf("����: %d->",i);
		while(out_node)
		{
			printf("%d->", out_node->headVex);
			out_node=out_node->hLink;
		}
		printf("NULL\n");
	}
}
int nodeAllVisited(Graph* g,int* visited,int* node_index)
{
	int i;
	for(i=0;i<g->vexnum;i++)
	{
		if(!visited[i])
		{
			*node_index=i;
			return 0;
		}
	}
	return 1;
}
void DFS(Graph* g,VextexNode** vextexNode)
{
	int* visited=(int* )malloc(g->vexnum*sizeof(int)),num;
	int node_index;
	struct ArcNode* arcNode=NULL;
	printf("DFS:\n");
	stack* s=NULL;
	VextexNode* vNode=vextexNode[0];
	memset(visited,0,g->vexnum*sizeof(int));
	visited[0]=1;
	num=1;
	printf("%c->",vNode->data);
	while(num!=g->vexnum)
	{
		arcNode=vNode->firstOut;
		struct ArcNode* node=arcNode;
		while(node&&visited[node->headVex])
		{
			node=node->hLink;	
		}
		if(!node)
		{
			if(stackEmpty(s))
			{
				if(!nodeAllVisited(g,visited,&node_index))
				{
					vNode=vextexNode[node_index];
					printf("%c->",vNode->data);
					visited[node_index]=1;
					num++;
				}
				else
				{
					break;
				}
			}
			else
			{
				pop(&s,&vNode);
			}
		}
		else
		{
			push(&s,vNode);
			vNode=vextexNode[node->headVex];
			visited[node->headVex]=1;
			num++;
			printf("%c->",vNode->data);
		}
	}
	printf("NULL\n");	
}
void BFS(Graph* g,VextexNode** vextexNode)
{
	int* visited=(int* )malloc(g->vexnum*sizeof(int)),node_index;
	linkQueue* queue=NULL;
	VextexNode* node;
	printf("BFS:\n");
	initQueue(&queue);
	enQueue(&queue,vextexNode[0]);
	memset(visited,0,g->vexnum*sizeof(int));
	visited[0]=1;
	while(!queueEmpty(queue))
	{
		deQueue(&queue,&node);
		printf("%c->",node->data);
		struct ArcNode* q=node->firstOut;
		while(q)
		{
			if(!visited[q->headVex])
			{
				visited[q->headVex]=1;
				enQueue(&queue,vextexNode[q->headVex]);
			}
			q=q->hLink;
		}
		if(queueEmpty(queue)&&!nodeAllVisited(g,visited,&node_index))
		{
			enQueue(&queue,vextexNode[node_index]);
			visited[node_index]=1;
		}
	}
	printf("NULL\n");
}
int allNodeVisited(Graph* g,int* visited)
{
	int i;
	for(i=0;i<g->vexnum;i++)
	{
		if(!visited[i])
		{
			return 0;
		}
	}
	return 1;
}
int getLength(ArcNode* arcNode)
{
	return arcNode?getLength(arcNode->tLink)+1:0;
}
void topoLogicalSort(Graph* g,VextexNode** vextexNode)
{
	int i,*inGree=(int* )malloc(g->vexnum*sizeof(int)),count=0,index=0;
	char* n=(char* )malloc(sizeof(char)*g->vexnum);
	VextexNode* node;
	memset(inGree,0,sizeof(int)*g->vexnum);
	Stack* stack=NULL;
	for(i=0;i<g->vexnum;i++)
	{
		inGree[i]=getLength(vextexNode[i]->firstIn);
	}
	for(i=0;i<g->vexnum;i++)
	{
		if(!inGree[i])
		{
			push(&stack,vextexNode[i]);
		}
	}
	while(!stackEmpty(stack))
	{
		pop(&stack,&node);
		count++;
		n[index++]=node->data;
		ArcNode* p=node->firstOut;
		while(p)
		{
			if(!--inGree[p->headVex])
			{
				push(&stack,vextexNode[p->headVex]);
			}
			p=p->hLink;
		}
	}
	if(count<g->vexnum)
	{
		printf("����ͼ���ڻ�·\n");
		return;
	}
	printf("��������:\n");
	for(i=0;i<g->vexnum;i++)
	{
		printf("%c ",n[i]);
	}
	printf("\n");
}
void topologicalSortting(Graph* g,VextexNode** vextexNode)
{
	int num=0,i=0,index=0;
	int* visited=(int* )malloc(g->vexnum*sizeof(int));
	char* n=(char* )malloc(sizeof(char)*g->vexnum);
	memset(visited,0,g->vexnum*sizeof(int));
	while(num<g->vexnum)
	{
		for(i=0;i<g->vexnum;i++)
		{
			if(!visited[i]&&!vextexNode[i]->firstIn)
			{
				ArcNode* arcNode=vextexNode[i]->firstOut,*p;
				while(arcNode)
				{
					p=vextexNode[arcNode->headVex]->firstIn;
					if(p->tailVex==i)
					{
						p=p->tLink;		
						vextexNode[arcNode->headVex]->firstIn=p;
					}
					else
					{
						while(p->tLink&&p->tLink->tailVex!=i)
						{
							p=p->tLink;
						}
						p->tLink=p->tLink->tLink;
					}
					arcNode=arcNode->hLink;
				}
				n[index++]=vextexNode[i]->data;
				visited[i]=1;
				num++;
				break;
			}
		}
		if(i==g->vexnum&&num<g->vexnum)
		{
			printf("����ͼ���ڻ�·\n");
			break;
		}
	}
	if(num==g->vexnum)
	{
		printf("��������:\n");
		for(i=0;i<g->vexnum;i++)
		{
			printf("%c ",n[i]);
		}
		printf("\n");
	}

}
/*
int main()
{
	struct Heap* heap=NULL;
	int i,arr[]={6,9,0,2,4,1,7,8,5,3},size=sizeof(arr)/sizeof(int);
	initHeap(&heap);
	for(i=0;i<size;i++)
	{
		insertHeap(&heap,arr[i]);
	}
	//heapSort(heap);
	while(heap->current_length>0)
	{
		for(i=0;i<heap->current_length;i++)
		{
			printf("%d ",heap->arr[i]);
		}
		printf("\n");
		deleteHeap(&heap);
	}
	free(heap->arr);
	free(heap);
	return 0;
}
*/