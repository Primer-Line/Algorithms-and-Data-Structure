typedef int dataType;
typedef char elemType;
struct Queue
{
	struct Queue* next;
	struct VextexNode* node;
};
typedef struct Queue queue;
typedef struct LinkQueue
{
	queue* front;
	queue* rear;
}linkQueue;
void visitQueue(linkQueue* queue);
struct VextexNode* getQueueTop(linkQueue* queue);
linkQueue* clearQueue(linkQueue* queue);
void enQueue(linkQueue** queue,struct VextexNode* node);
void deQueue(linkQueue** queue,struct VextexNode** node);
dataType queueEmpty(linkQueue* queue);
dataType getQueueSize(linkQueue* queue);
void initQueue(linkQueue** queue)
{
	(*queue)=(linkQueue*)malloc(sizeof(struct LinkQueue));
	if(!(*queue))
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	(*queue)->front=(*queue)->rear=(struct Queue* )malloc(sizeof(struct Queue));
}
dataType getQueueSize(linkQueue* lQueue)
{
	queue* q=lQueue->front,*p=lQueue->rear;
	dataType length=0;
	while(q!=p)
	{
		length++;
		q=q->next;
	}
	return length;
}
dataType queueEmpty(linkQueue* queue)
{
	if(queue->front==queue->rear)
	{
		return 1;
	}
	return 0;
}
struct VextexNode* getQueueTop(linkQueue* queue)
{
	return queue->front->next->node;
}
/*
void visitQueue(linkQueue* lQueue)
{
	queue* q=lQueue->front,*p=lQueue->rear;
	while(q!=p)
	{	
		q=q->next;
		printf("%d ",q->root->data);
	}
	printf("\n");
}
*/
void enQueue(linkQueue** lQueue,struct VextexNode* node)
{
	queue* q=NULL;
	q=(queue* )malloc(sizeof(struct Queue));
	if(!q)
	{
		printf("�ڴ����ʧ��\n");
		exit(-1);
	}
	q->node=node;
	if((*lQueue)->front==(*lQueue)->rear)
	{
		(*lQueue)->rear=q;
		(*lQueue)->front->next=(*lQueue)->rear;
		return;
	}
	(*lQueue)->rear->next=q;
	(*lQueue)->rear=q;
}
void deQueue(linkQueue** lQueue,struct VextexNode** node)
{
	queue* q=(*lQueue)->front;
	if(q->next==(*lQueue)->rear)
	{
		*node=(*lQueue)->rear->node;
		(*lQueue)->rear=(*lQueue)->front;
		return;
	}
	*node=(*lQueue)->front->next->node;
	(*lQueue)->front->next=(*lQueue)->front->next->next;
}
