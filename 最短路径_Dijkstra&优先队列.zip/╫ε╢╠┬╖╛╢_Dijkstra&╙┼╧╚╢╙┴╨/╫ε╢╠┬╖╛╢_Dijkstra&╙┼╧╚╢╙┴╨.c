#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include"queue.h"
#define MAX_VALUE (2<<30)-1//�������
//�ڽӱ��Ĵ洢�ṹ(�����ʾ)
typedef struct AdjList
{
	UINT length;//����
	UINT** arc;//�����Ȩֵ
}*List;
//�����ڽӱ�
void createGraph(List** l,dataType arc[][3],UINT n,UINT adjvex_num)
{
	UINT i,*degree = (UINT*)malloc(sizeof(UINT)*adjvex_num);
	List* list = (List*)malloc(sizeof(List)*adjvex_num);
	if(!list || !degree)exit(-1);
	memset(list,0x00,sizeof(List)*adjvex_num);
	memset(degree,0,sizeof(UINT)*adjvex_num);
	//����ÿ������Ķ�
	for(i=0;i<n;i++)
	{
		degree[arc[i][0]]++;
		degree[arc[i][1]]++;
	}
	//�����ڽӱ�
	for(i=0;i<n;i++)
	{
		if(!list[arc[i][0]])
		{
			list[arc[i][0]] = (struct AdjList*)malloc(sizeof(struct AdjList)); 		
			list[arc[i][0]]->arc = (UINT**)malloc(sizeof(UINT*)*degree[arc[i][0]]);
			list[arc[i][0]]->length = degree[arc[i][0]];
		}
		if(!list[arc[i][1]])
		{
			list[arc[i][1]] = (struct AdjList*)malloc(sizeof(struct AdjList)); 		
			list[arc[i][1]]->arc = (UINT**)malloc(sizeof(UINT*)*degree[arc[i][1]]);
			list[arc[i][1]]->length = degree[arc[i][1]];
		}
		list[arc[i][0]]->arc[--degree[arc[i][0]]] = (UINT*)malloc(sizeof(UINT)*2);
		list[arc[i][0]]->arc[degree[arc[i][0]]][0] = arc[i][1];
		list[arc[i][0]]->arc[degree[arc[i][0]]][1] = arc[i][2];	
		list[arc[i][1]]->arc[--degree[arc[i][1]]] = (UINT*)malloc(sizeof(UINT)*2);
		list[arc[i][1]]->arc[degree[arc[i][1]]][0] = arc[i][0];
		list[arc[i][1]]->arc[degree[arc[i][1]]][1] = arc[i][2];	
	}
	free(degree);
	*l = list;//�����ڽӱ�
}
//���·��Dijkstra�㷨
void shortestPath_Dijkstra(dataType arc[][3],char* adjvex,UINT n,UINT adjvex_num)
{
	UINT i,count = 1,pos=0,num = 0,j;
	priority_queue* queue = NULL;
	edge* e = (edge*)malloc(sizeof(edge)*n),*node;
	UINT* visited = (UINT*)malloc(sizeof(UINT)*adjvex_num);
	UINT* shortestPath = (UINT*)malloc(sizeof(UINT)*adjvex_num);
	List* l = NULL;
	if(!e||!visited||!shortestPath)exit(-1);
	createGraph(&l,arc,n,adjvex_num);//�����ڽӱ�
	initHeap(&queue);//��ʼ�����ȶ���
	memset(visited,0,sizeof(UINT)*adjvex_num);
	memset(shortestPath,MAX_VALUE,sizeof(UINT)*adjvex_num);//��ʼ�����·�� �������
	shortestPath[0] = 0;
	while(count++ < n)
	{
		if(pos != -1)//��ǰ����ֻ����û�����ʵ������ �Ŵ��ڲ��ظ��ı�
		{
			visited[pos] = 1;
			for(i=0;i<l[pos]->length;i++)
			{
				if(!visited[l[pos]->arc[i][0]])
				{
					e[num].arc[0] = pos;
					e[num].arc[1] = l[pos]->arc[i][0];
					e[num].weight = l[pos]->arc[i][1];
					insertHeap(&queue,&e[num++]);//�����
				}
			}
		}
		deleteHeap(&queue,&node);//ɾ���Ѷ��ڵ㲢����
		if(!visited[node->arc[1]])pos = node->arc[1];
		else pos = -1;
		//�������·��
		if(shortestPath[node->arc[0]]!=MAX_VALUE)shortestPath[node->arc[1]] = shortestPath[node->arc[1]] < shortestPath[node->arc[0]] + node->weight ? shortestPath[node->arc[1]] : shortestPath[node->arc[0]] + node->weight;
	}
	printf("���·��\n");//��ʾ���·��
	for(i=0;i<adjvex_num;i++)
	{
		printf("A->%c  %d\n",toupper(adjvex[i]),shortestPath[i]);
	}
	//�ͷ�ָ��
	for(i=0;i<adjvex_num;i++)
	{
		for(j=0;j<l[i]->length;j++)
		{
			free(l[i]->arc[j]);
			l[i]->arc[j]=NULL;
		}
		free(l[i]->arc);
		l[i]->arc=NULL;
		free(l[i]);
		l[i]=NULL;
	}
	free(l);
	l=NULL;
	free(visited);
	visited=NULL;
	free(e);
	e=NULL;
	free(queue->arr);
	queue->arr=NULL;
	free(queue);
	queue=NULL;
}
int main()
{
	dataType arc[][3]={{0,3,5},{0,1,7},{1,2,8},{1,3,9},{2,4,5},{1,4,7},{3,5,6},{3,4,15},{5,6,11},{4,6,9},{4,5,8}};
	UINT n = sizeof(arc)/sizeof(arc[0]);
	char ch[]={'a','b','c','d','e','f','g'};
	UINT adjvex_num = sizeof(ch)/sizeof(char);
	shortestPath_Dijkstra(arc,ch,n,adjvex_num);
	return 0;
}